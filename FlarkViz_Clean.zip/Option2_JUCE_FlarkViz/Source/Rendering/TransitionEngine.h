#pragma once
#include <JuceHeader.h>
class TransitionEngine { public: TransitionEngine() {} ~TransitionEngine() {} };
