#pragma once
#include <JuceHeader.h>
class ShaderCompiler { public: ShaderCompiler() {} ~ShaderCompiler() {} };
