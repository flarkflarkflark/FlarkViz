#pragma once
#include <JuceHeader.h>
class MilkdropEval { public: MilkdropEval() {} ~MilkdropEval() {} };
