#pragma once
#include <JuceHeader.h>
class Milk2Loader { public: Milk2Loader() {} ~Milk2Loader() {} };
