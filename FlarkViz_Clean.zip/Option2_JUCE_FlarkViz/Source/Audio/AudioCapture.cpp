#include "AudioCapture.h"
// Implementation will be added in future versions
